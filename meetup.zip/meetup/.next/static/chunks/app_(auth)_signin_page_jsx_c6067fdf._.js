(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_8609bb6b._.js",
  "static/chunks/_4dbf446f._.js"
],
    source: "dynamic"
});
