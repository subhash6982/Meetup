'use client'

import { useRouter } from 'next/navigation'

export default function HomePage() {
  const router = useRouter()

  return (
    <main className="flex flex-col min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white font-sans">
      
      {/* Navbar */}
      <header className="w-full flex items-center justify-between px-6 py-4 shadow-sm backdrop-blur-md bg-gray-900/70 sticky top-0 z-10 border-b border-gray-800">
        <h1 className="text-2xl font-extrabold text-white tracking-tight">Meetup</h1>
        <nav>
          <button
            onClick={() => router.push('/signin')}
            className="bg-white/10 hover:bg-white/20 text-white px-5 py-2 rounded-xl transition duration-200 border border-white/10"
          >
            Sign In
          </button>
        </nav>
      </header>

      {/* Main Content */}
      <section className="flex-grow flex items-center justify-center px-4 sm:px-8 py-10">
        <div className="flex flex-col md:flex-row items-center gap-16 max-w-7xl w-full">
          
          {/* Left */}
          <div className="flex-1 max-w-xl text-center md:text-left">
            <h2 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight text-white">
              Seamless meetings,<br className="hidden md:block" /> crafted for collaboration
            </h2>
            <p className="text-gray-400 text-lg mb-8">
              Create instant connections in one click. Elegant. Secure. Effortless.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => alert('Starting a new meeting...')}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-semibold shadow-lg transition duration-200"
              >
                🎥 New Meeting
              </button>
              <div className="flex items-center bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl overflow-hidden w-full sm:w-auto">
                <input
                  type="text"
                  placeholder="Enter code or link"
                  className="px-4 py-2 bg-transparent text-white placeholder-gray-400 outline-none w-full"
                />
                <button className="px-4 py-2 text-indigo-400 hover:text-indigo-300 transition">
                  Join
                </button>
              </div>
            </div>

            <div className="mt-5 text-sm">
              <a href="#" className="text-indigo-400 hover:underline">
                Learn more
              </a>{' '}
              about Meetup
            </div>
          </div>

          {/* Right - Features List */}
          <div className="flex-1 max-w-md w-full">
            <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-3xl p-8 shadow-xl space-y-8">
              <h3 className="text-center text-2xl font-bold text-indigo-400 mb-6">
                Why Choose Meetup?
              </h3>

              <ul className="space-y-6">
                <li className="flex items-start gap-4">
                  <div className="flex-shrink-0 bg-indigo-600 rounded-lg p-3 shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-white font-semibold text-lg">Instant Setup</h4>
                    <p className="text-gray-300 text-sm">
                      Start or join meetings with a single click — no delays or downloads.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-4">
                  <div className="flex-shrink-0 bg-indigo-600 rounded-lg p-3 shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M7 8h10M7 12h4m1 8h1a2 2 0 002-2v-5a2 2 0 00-2-2h-1m-4 9H7a2 2 0 01-2-2v-5a2 2 0 012-2h1" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-white font-semibold text-lg">Secure & Private</h4>
                    <p className="text-gray-300 text-sm">
                      End-to-end encryption and privacy controls to keep your meetings safe.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-4">
                  <div className="flex-shrink-0 bg-indigo-600 rounded-lg p-3 shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-white font-semibold text-lg">Effortless Collaboration</h4>
                    <p className="text-gray-300 text-sm">
                      Share screens, chat, and collaborate seamlessly—all in one place.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center text-xs text-gray-500 py-6 border-t border-gray-800">
        © {new Date().getFullYear()} Meetup. All rights reserved.
      </footer>
    </main>
  )
}
