'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createUserWithEmailAndPassword, signInWithPopup } from 'firebase/auth'
import { auth, provider } from '../../app/firebase'
import Link from 'next/link'

export default function SignUp() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')

  const handleEmailSignUp = async (e) => {
    e.preventDefault()
    if (password !== confirmPassword) {
      setError('Passwords do not match.')
      return
    }
    try {
      await createUserWithEmailAndPassword(auth, email, password)
      router.push('/signin')
    } catch (err) {
      setError(err.message)
    }
  }

  const handleGoogleSignIn = async () => {
    try {
      await signInWithPopup(auth, provider)
      router.push('/dashboard')
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white font-sans flex flex-col">
      {/* Navbar */}
      <header className="w-full flex items-center justify-between px-6 py-4 shadow-sm backdrop-blur-md bg-gray-900/70 sticky top-0 z-10 border-b border-gray-800">
        <h1 className="text-2xl font-extrabold text-white tracking-tight">Meetup</h1>
        <nav>
          <Link
            href="/about"
            className="text-indigo-400 hover:text-indigo-300 font-semibold transition duration-200"
          >
            About
          </Link>
        </nav>
      </header>

      {/* Sign Up Form */}
      <section className="flex-grow flex items-center justify-center px-4 sm:px-8 py-12">
        <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-3xl p-10 max-w-md w-full shadow-xl">
          <h1 className="text-3xl font-extrabold text-center mb-8">Sign Up</h1>
          {error && (
            <p className="text-red-500 text-sm mb-6 text-center break-words">{error}</p>
          )}

          <form onSubmit={handleEmailSignUp} className="space-y-6">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-5 py-3 rounded-xl bg-white/20 placeholder-gray-300 text-white border border-white/30 focus:border-indigo-500 outline-none transition"
              required
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-5 py-3 rounded-xl bg-white/20 placeholder-gray-300 text-white border border-white/30 focus:border-indigo-500 outline-none transition"
              required
            />
            <input
              type="password"
              placeholder="Confirm Password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full px-5 py-3 rounded-xl bg-white/20 placeholder-gray-300 text-white border border-white/30 focus:border-indigo-500 outline-none transition"
              required
            />
            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-semibold shadow-lg transition duration-200"
            >
              Sign Up
            </button>
          </form>

          <div className="text-center my-6 text-gray-400">or</div>

          <button
            onClick={handleGoogleSignIn}
            className="w-full flex justify-center items-center gap-3 border border-white/30 py-3 rounded-xl hover:bg-white/10 transition text-white font-semibold"
          >
            <img src="/google-icon.svg" alt="Google" className="w-6 h-6" />
            Sign up with Google
          </button>

          <p className="text-center text-sm mt-8 text-gray-400">
            Already have an account?{' '}
            <Link href="/auth/signin" className="text-indigo-400 hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </section>
    </main>
  )
}
