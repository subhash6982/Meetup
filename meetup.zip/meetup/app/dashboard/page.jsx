import React from "react";
import Body from "@/components/Homepage/Body";

const page = () => {
  return (
    <div>
      <Body />
    </div>
  );
};

export default page;
