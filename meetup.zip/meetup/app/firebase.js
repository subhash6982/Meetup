// lib/firebase.js
import { initializeApp } from 'firebase/app'
import { getAuth, GoogleAuthProvider } from 'firebase/auth'
 


const firebaseConfig = {
  apiKey: "AIzaSyDVDiBjW3lBORQwzLWs6E6m07m2fYR2jOw",
  authDomain: "meet-7326c.firebaseapp.com",
  projectId: "meet-7326c",
  storageBucket: "meet-7326c.appspot.com",
  messagingSenderId: "226366555697",
  appId: "1:226366555697:web:76bb7c43f208fb883c7710",
  measurementId: "G-XFNWF5NMKL"
}


const app = initializeApp(firebaseConfig)
const auth = getAuth(app)
const provider = new GoogleAuthProvider()

export { auth, provider }
