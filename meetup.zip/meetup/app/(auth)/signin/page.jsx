import React from "react";
import Signin from "@/components/Homepage/Signin";


const page = () => {
  return (
    <div>
      <Signin />
      {/* <SignupButton /> */}
    </div>
  );
};

export default page;
