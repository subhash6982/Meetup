import React from "react";
import Signup from "@/components/Homepage/Signup";


const page = () => {
  return (
    <div>
      <Signup />
      {/* <SignupButton /> */}
    </div>
  );
};

export default page;
